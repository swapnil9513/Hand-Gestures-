import cv2
import mediapipe as mp
import pygame
import os
import time
import math
import numpy as np

# Initialize Mediapipe for hand tracking
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
hands = mp_hands.Hands(min_detection_confidence=0.8, min_tracking_confidence=0.8)

# Finger landmark indices
finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky

# Load songs from the "songs" folder
songs = [file for file in os.listdir(".") if file.endswith(".mp3")]
current_song_index = 0

# Initialize Pygame Mixer for music
pygame.mixer.init()
pygame.mixer.music.load(songs[current_song_index])
pygame.mixer.music.play()

# Set volume to 50% initially
pygame.mixer.music.set_volume(0.5)

# Open webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

cv2.namedWindow("Hand Tracking", cv2.WINDOW_NORMAL)

# Cooldown timer
last_action_time = time.time()

def get_distance(x1, y1, x2, y2):
    """Calculate Euclidean distance between two points"""
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

def is_finger_up(hand_landmarks, tip, base):
    """Determine if a finger is up based on its relative position"""
    return hand_landmarks.landmark[tip].y < hand_landmarks.landmark[base].y - 0.02  # Adding buffer threshold

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error: Failed to capture frame.")
        break

    # Flip for mirror effect
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            # Improved finger detection
            fingers = [
                is_finger_up(hand_landmarks, 4, 3),  # Thumb
                is_finger_up(hand_landmarks, 8, 6),  # Index
                is_finger_up(hand_landmarks, 12, 10),  # Middle
                is_finger_up(hand_landmarks, 16, 14),  # Ring
                is_finger_up(hand_landmarks, 20, 18)  # Pinky
            ]
            fingers = [1 if f else 0 for f in fingers]

            # Get thumb and index finger positions for volume control
            thumb_x, thumb_y = hand_landmarks.landmark[4].x, hand_landmarks.landmark[4].y
            index_x, index_y = hand_landmarks.landmark[8].x, hand_landmarks.landmark[8].y
            distance = get_distance(thumb_x, thumb_y, index_x, index_y)

            # Map distance to volume (range 0 to 1)
            volume = min(max(distance * 5, 0), 1)  # Scale and clamp between 0-1
            pygame.mixer.music.set_volume(volume)

            # Display volume on screen
            cv2.putText(frame, f"Volume: {int(volume * 100)}%", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 
                        1, (0, 255, 0), 2)

            print(f"Fingers Up: {fingers}, Volume: {int(volume * 100)}%")

            # Cooldown check (2 seconds between actions)
            current_time = time.time()
            if current_time - last_action_time >= 2:
                if fingers == [0, 0, 0, 0, 0]:  # Fist (Play/Pause)
                    if pygame.mixer.music.get_busy():
                        pygame.mixer.music.pause()
                        print("⏸ Music Paused")
                    else:
                        pygame.mixer.music.unpause()
                        print("▶️ Music Playing")
                    last_action_time = current_time

                elif fingers == [0, 1, 0, 0, 0]:  # Index Finger Up (Next Song)
                    current_song_index = (current_song_index + 1) % len(songs)
                    pygame.mixer.music.load(songs[current_song_index])
                    pygame.mixer.music.play()
                    print(f"⏭ Playing Next: {songs[current_song_index]}")
                    last_action_time = current_time

                elif fingers == [1, 0, 0, 0, 0]:  # Thumb Up (Previous Song)
                    current_song_index = (current_song_index - 1) % len(songs)
                    pygame.mixer.music.load(songs[current_song_index])
                    pygame.mixer.music.play()
                    print(f"⏮ Playing Previous: {songs[current_song_index]}")
                    last_action_time = current_time

                elif fingers == [0, 1, 1, 0, 0]:  # Index & Middle Finger Up (Stop)
                    pygame.mixer.music.stop()
                    print("🛑 Music Stopped")
                    last_action_time = current_time

    # Show Video
    cv2.imshow("Hand Tracking", frame)

    # Exit with 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
